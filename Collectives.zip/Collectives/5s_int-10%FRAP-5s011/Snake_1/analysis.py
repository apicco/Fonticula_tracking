from trajalign.traj import Traj
from trajalign.average import load_directory
from matplotlib import pyplot as plt
from scipy.stats import median_absolute_deviation as mad

import numpy as np
import seaborn as sns
import os

path =  '/Users/andreapicco/Google Drive/RESEARCH/FONTICULA/Fonticula-speeds/Snakes/5s_int-10%FRAP-5s011/Snake_1/Trajectories/'
t = load_directory( path , 
		pattern = 'x' ,
		comment_char = "%%" , 
		frames = 0 ,
		coord = ( 1 , 2 ) ,
		dt = 5 , 
		t_unit = 's' ,
		coord_unit = 'pxl' ,
		notes = "fonticula snakes"
		)

l = len( t )
filter_length = 15
v = []
D = []
v_step = []

colorpalette = sns.color_palette( None , l )

f , ax = plt.subplots( 2 , 2 , figsize = ( 10 , 10 ) )

for i in range( l ) :

	# select only trajectories long enough for a reliable msd analysis
	if len( t[ i ] ) >= filter_length :
		x = [ xx for xx in t[ i ].coord()[ 0 ] if xx == xx ]
		y = [ yy for yy in t[ i ].coord()[ 1 ] if yy == yy ]
		#ax[ 0 , 0 ].plot( x , y , color = colorpalette[ i ] )
	
		v_tmp , D_tmp , m = t[ i ].msdfit( sel = 5 , scale = 6.45/20 , return_data = True )

		# if diffusion D is negative, something went wrong, dump this trajectory
		if D_tmp[ 0 ] > 0 :
			ax[ 0 , 1 ].errorbar( m[ 'x' ] , m[ 'y' ] , yerr = m[ 'err' ] , color = colorpalette[ i ] )
			
			v.append( v_tmp[ 0 ] )
			D.append( D_tmp[ 0 ] )

			#compute the individual speed steps
			for j in range( len( t[ i ] ) -1 ) :

				d = np.sqrt( ( t[ i ].coord()[ 0 ][ j ] - t[ i ].coord()[ 0 ][ j + 1 ] ) ** 2 + ( t[ i ].coord()[ 1 ][ j ] - t[ i ].coord()[ 1 ][ j ] ) ** 2 )
				v_step.append( d / float( t[ i ].annotations()[ 'delta_t' ] ) ) 

#ax[ 0 , 0 ].grid()
#ax[ 0 , 0 ].set_xlabel( 'Pixel' )
#ax[ 0 , 0 ].set_ylabel( 'Pixel' )

ax[ 0 , 0 ].hist( v_step , density = True )
ax[ 0 , 0 ].set_xlabel( '$v$ ' +'$(\\mu m/s)$' )
ax[ 0 , 0 ].set_ylabel( 'Density' )
ax[ 0 , 0 ].set_xlim( 0 , 3.5 )
ax[ 0 , 0 ].plot( [ max( v_step ), max( v_step ) ] , [ 0 , 1 ] , 'r--' , label = 'max speed value' )
ax[ 0 , 0 ].set_title( '$\\|\\bar{v}\\|$ of single steps' )
ax[ 0 , 0 ].legend()

ax[ 0 , 1 ].set_xlabel( '$\\Delta t$' )
ax[ 0 , 1 ].set_ylabel( 'MSD ' + '$(\\mu m^2)$' )
ax[ 0 , 1 ].set_ylim( 0 , 60 )

velocity = []
velocity.append( np.nanmedian( v ) )
vm = mad( np.log( v ) , nan_policy = 'omit' )#, scale = 'normal' )
velocity.append( velocity[ 0 ] * vm )

ax[ 1 , 0 ].hist( v ) 
ax[ 1 , 0 ].set_title(
		'$\\langle \\|\\bar{v}\\| \\rangle$: ' + 
		str( round( velocity[ 0 ] , 2 ) ) + 
		' $\\pm$ ' + 
		str( round( velocity[ 1 ] , 2 ) ) + 
		' $\\mu m/s$,' +
		' $n=$' + str( len( v ) )
)

ax[ 1 , 0 ].set_xlabel( '$v$ ' +'$(\\mu m/s)$' )
ax[ 1 , 0 ].set_ylabel( 'Frequency' )

diffusion = []
diffusion.append( np.nanmedian( D ) )
Dm = mad( np.log( D ) , nan_policy = 'omit' )#, scale = 'normal' )
diffusion.append( diffusion[ 0 ] * Dm )

ax[ 1 , 1 ].hist( D )
ax[ 1 , 1 ].set_title( 
		'$\\langle D\\rangle$: ' + 
		str( round( diffusion[ 0 ] , 2 ) ) + 
		' $\\pm$ ' + 
		str( round( diffusion[ 1 ] , 2 ) ) + 
		' $\\mu m^2/s$,' +
		' $n=$' + str( len( D ) )
)
ax[ 1 , 1 ].set_xlabel( '$D$ ' +'$(\\mu m^2/s)$' )
ax[ 1 , 1 ].set_ylabel( 'Frequency' )

plt.savefig( '/Users/andreapicco/Google Drive/RESEARCH/FONTICULA/Fonticula-speeds/Snakes/5s_int-10%FRAP-5s011/Snake_1/snake_1.pdf' )

print( velocity )

