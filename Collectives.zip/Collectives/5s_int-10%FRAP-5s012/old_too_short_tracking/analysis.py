from trajalign.traj import Traj
from trajalign.average import load_directory
from matplotlib import pyplot as plt
import numpy as np
import seaborn as sns
import os

path =  'snake_1/'
t = load_directory( path , 
		pattern = 'x' ,
		comment_char = "%%" , 
		frames = 0 ,
		coord = ( 1 , 2 ) ,
		dt = 5 , 
		t_unit = 's' ,
		coord_unit = 'pxl' ,
		notes = "fonticula snake 1"
		)

l = len( t )
v = []
D = []

colorpalette = sns.color_palette( None , l )

f , ax = plt.subplots( 2 , 2 , figsize = ( 10 , 10 ) )

for i in range( l ) :

	ax[ 0 , 0 ].plot( t[ i ].coord()[ 0 ] , t[ i ].coord()[ 1 ] , color = colorpalette[ i ] )

	v , D = t[ i ].msdfit( scale = 6.45/60 )
	v.append( v[ 0 ] )
	D.append( D[ 0 ] )
print( v )
ax[ 1 , 0 ].hist( v )
ax[ 1 , 1 ].hist( D )
plt.savefig( 'tmp.pdf' )


