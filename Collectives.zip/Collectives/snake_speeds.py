from matplotlib import pyplot as plt

#exec( open( '5s_int-10%FRAP-5s010/Snake_left/analysis.py' ).read() )
#s.append( velocity )
#
#exec( open( '5s_int-10%FRAP-5s010/Snake_right/analysis.py' ).read() )
#s.append( velocity )
#
#exec( open( '5s_int-10%FRAP-5s011/Snake_1/analysis.py' ).read() )
#s.append( velocity )
#
#exec( open( '5s_int-10%FRAP-5s012/snakes_1_2/analysis.py' ).read() )
#s.append( velocity )

exec( open( '/Users/andreapicco/Google Drive/RESEARCH/FONTICULA/Fonticula-speeds/plots_snakes_and_single_cells/analysis.py' ).read() )


#exec( open( '../Single_cells_on_snake_movie/analysis.py' ).read() )
#ss = velocity

f , ax = plt.subplots( 1 , 1 , figsize = ( 6 , 5 ) )
#f , ( ax , bx ) = plt.subplots( 1 , 2 , figsize = ( 12 , 5 ) )

ax.bar( 0 , velocity_snake[ 0 ] , color = 'blue' , alpha = 0.5 , label = 'Snakes' )
ax.errorbar( 0 , velocity_snake[ 0 ] , velocity_snake[ 1 ] , color = 'blue' , ls = '' , marker = '' , capsize = 10 )
ax.bar( 1 , velocity_cell[ 0 ] , color = 'orange' , alpha = 0.5 , label = 'Single cells' )
ax.errorbar( 1 , velocity_cell[ 0 ] , velocity_cell[ 1 ] , color = 'orange' , ls = '' , marker = '' , capsize = 10 )
ax.set_ylabel( '$\\mu m/s$' )
ax.set_xticklabels( [ ] )
ax.set_xticks( [ ] )
ax.set_title( 'Velocity' )

#bx.bar( 0 , speed_snake[ 0 ] , color = 'blue' , alpha = 0.5 , label = 'Snakes' )
#bx.errorbar( 0 , speed_snake[ 0 ] , speed_snake[ 1 ] , color = 'blue' , ls = '' , marker = '' , capsize = 10 )
#bx.bar( 1 , speed_cell[ 0 ] , color = 'orange' , alpha = 0.5 , label = 'Single cells' )
#bx.errorbar( 1 , speed_cell[ 0 ] , speed_cell[ 1 ] , color = 'orange' , ls = '' , marker = '' , capsize = 10 )
#bx.set_ylabel( '$\\mu m/s$' )
#bx.set_xticklabels( [ ] ) 
#bx.set_title( 'Speed' )


plt.legend()
plt.savefig( 'snake_speeds.pdf' )
