from matplotlib import pyplot as plt
from matplotlib import gridspec as gspec 
from skimage.external import tifffile as tiff

from trajalign.traj import Traj
from trajalign.average import load_directory
import numpy as np
import seaborn as sns
import os
def print_frames( path_im , path_frames , path_trajectories ) :

	if not os.path.isdir( path_frames ) :
		os.mkdir( path_frames )

	# params
	# scale pixels in um
	scale = 16 / 60 # pixel size / magnification, in um
	# select msd values to compute velocity and diffusion
	sel = 15
	# load the trajectories
	t = load_directory( path_trajectories , 
			frames = 0 , 
			t = 1 ,
			coord = ( 2, 3 ) , 
			f = 4 ,
			ecc = 5 ,
			coord_unit = 'pxl' ,
			t_unit = 's' ,
			movie = path_im
			)

	# compute the msd here, for the sake of speed, so that they are not 
	# recounted on each frame
	msd = []
	for i in range( len( t ) ) :
		msd.append( t[ i ].extract( range( 0 , min( len( t[ i ] ) , 50 ) ) ).msd() )

	# color palette 
	c = sns.color_palette( None , len( t ) )

	# load the image
	im = tiff.imread( path_im )

	# print a frame with thrajectories on it
	frames = range( im.shape[ 0 ] )
	for f in frames :

		fig = plt.figure( figsize = ( 11 , 6 ) ) 
		gs = gspec.GridSpec( nrows = 3 , ncols = 5 )#, width_ratios = [ 2 , 2 , 1 ] )
		
		# define the axes

		ax_frame = fig.add_subplot( gs[ : , :4 ] )
		ax_msd = fig.add_subplot( gs[ 0 , 4 ] )
		ax_ecc = fig.add_subplot( gs[ 1 , 4 ] )
		ax_area = fig.add_subplot( gs[ 2 , 4 ] )
		
		# print the frame
		ax_frame.imshow( im[ f , : , : ] , cmap = 'gray' )

		# add trajectories to _frame , _msd, and_ecc
		for i in range( len( t ) ) :

			# print picture with trajectory	
			te = t[ i ].extract( range( 0 , f + 1 ) )
			ax_frame.plot( te.coord()[ 0 ], te.coord()[ 1 ] , color = c[ i ] , label = te.annotations()[ 'file' ] )

			# show  msd
			dt = float( t[ i ].annotations()[ 'delta_t' ]  )

			xf = msd[ i ][ 0 ][ 0 : sel ] * dt
			yf = msd[ i ][ 1 ][ 0 : sel ] * scale ** 2 
			err = msd[ i ][ 2 ][ 0 : sel ] * scale ** 2

			p , cov = np.polyfit( xf , yf , w = 1 / err , deg = 2 , cov = True )
			v = np.sqrt( p[ 0 ] )
			ax_msd.errorbar( xf , yf , yerr = err , color = c[ i ] , label = '$v=$' + str( round( v , 2 ) ) + '$\\frac{\\mu m}{s}$' )
			
			# show eccentricity
			ax_ecc.plot( t[ i ].t() , t[ i ].ecc() , color = c[ i ] , ls = 'dashed' , alpha = 0.3 )
			ax_ecc.plot( te.t() , te.ecc() , color = c[ i ] )

			# show area
			ax_area.plot( t[ i ].t() , t[ i ].f() * scale ** 2 , color = c[ i ] , ls = 'dashed' , alpha = 0.3 )
			ax_area.plot( te.t() , te.f() * scale ** 2 , color = c[ i ] )
	
		ax_frame.legend()
		ax_frame.set_xlabel( 'Pixel' )
		ax_frame.set_ylabel( 'Pixel' )

		ax_msd.grid()
		ax_msd.legend()
		#ax_msd.set_xlim( 0 , 75 ) 
		#ax_msd.set_ylim( 0 , 200 ) 
		ax_msd.set_xlabel( '$\\Delta t$ (s)' )
		ax_msd.set_ylabel( 'MSD ($\\mu m^2$)' )

		ax_ecc.grid()
		#ax_ecc.set_ylim( 0 , 1 ) 
		ax_ecc.set_xlabel( 'Frame' )
		ax_ecc.set_ylabel( 'Eccentricity' )

		ax_area.grid()
		ax_area.set_xlabel( 'Frame' )
		ax_area.set_ylabel( 'Area ($\\mu m^2$)' )

		fig.tight_layout()
		plt.savefig( path_frames + '/frame_' + str( f ).zfill( 3 ) + '.png' )
		plt.close()

print_frames( '012/012.tif' , '012/frames' , '012/trajectories' )
